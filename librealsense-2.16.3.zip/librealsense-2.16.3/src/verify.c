/* License: Apache 2.0. See LICENSE file in root directory.
   Copyright(c) 2015 Intel Corporation. All Rights Reserved. */

/* This file simply verifies that rs.h and rs2_advanced_mode.h can be correctly included by a C compiler */
#include "../include/librealsense2/rs.h"
#include "../include/librealsense2/rs_advanced_mode.h"
